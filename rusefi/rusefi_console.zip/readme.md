rusEFI uses http://launch4j.sourceforge.net/ to create console launcher

See docs/frontend.md
